import Assignments from "./Assignments.js";
export default {
    components: {
        Assignments
    },
    template: `
    <Assignments />
    `,

};